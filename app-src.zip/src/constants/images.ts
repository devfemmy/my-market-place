const LinkLogo = require("../assets/images/message.png") as number
const GoogleLogo = require("../assets/images/google.png") as number
const AppleLogo = require("../assets/images/Apple.png") as number
const SuccesssLogo = require("../assets/images/alert_icon.png") as number
const FailedLogo = require("../assets/error.png") as number
const NoProducts = require("../assets/images/package.png") as number
const NoOrders = require("../assets/images/bag.png") as number
const UniversityLogo = require("../assets/images/Vector.png") as number
const PayoutBack = require("../assets/images/Payoutback.png") as number

export { LinkLogo, GoogleLogo, AppleLogo, SuccesssLogo, FailedLogo, NoProducts, NoOrders, UniversityLogo, PayoutBack }