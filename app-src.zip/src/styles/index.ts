export * from './globalStyles';
