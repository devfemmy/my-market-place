/* eslint-disable @typescript-eslint/no-explicit-any */
import {createContext} from 'react';
export const AuthContext = createContext<any>('');
